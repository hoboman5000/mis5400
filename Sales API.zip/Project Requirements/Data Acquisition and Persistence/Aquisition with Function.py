
import pyodbc
import csv

#  database connection string variables
server = *************
database = ***********
username = **********
password = **********
driver = '{ODBC Driver 17 for SQL Server}'

#  Connection String
cnxn = pyodbc.connect('DRIVER='+driver+';SERVER='+server+';PORT=1433;DATABASE='+database+';UID='+username+';PWD='+ password, autocommit=True, timeout=30)

#  Query Function


def query_db( table_name, file_name ):
    cur = cnxn.cursor()
    query = f'select * from {table_name}'
    table_data = cur.execute(query)
    with open(f'{file_name}.csv', 'w', newline='') as fd:
        a = csv.writer(fd, delimiter=',')
        file_data = table_data
        for line in file_data:
            a.writerow(line)
    cur.close()


#  Queries In Action
query_db(table_name='Feature', file_name='feature')
query_db(table_name='Ticket_Sales', file_name='ticket_sales')
query_db(table_name='Concession_Sales', file_name='concession_sales')
query_db(table_name='Employee', file_name='employee')
query_db(table_name='Sales', file_name='sales')

#  Close and Delete Connection
cnxn.close()
del cnxn
