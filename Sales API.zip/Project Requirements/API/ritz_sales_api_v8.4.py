"""The Ritz Theater Sales API by Mike Booth and Nate Laursen. A project for MIS 5400 at Utah State University"""

import pyodbc
from flask import Flask, g, render_template, abort, request, Response
from decimal import *
import datetime


#  database connection
server = '********'
database = '********'
username = '********'
password = '********'
driver = '{ODBC Driver 17 for SQL Server}'

CONNECTION_STRING = f"DRIVER= {driver};SERVER={server};PORT=1433;DATABASE={database};UID={username};PWD={password}"

#  Setup Flask
app = Flask(__name__)


#  Formatting Functions
def format_date_string(string_to_format):
    return datetime.datetime.strptime(string_to_format.replace('/', '-'), '%Y-%m-%d')


#  Open Connection to Database
@app.before_request
def before_request():
    try:
        g.sql_conn = pyodbc.connect(CONNECTION_STRING, autocommit=True, timeout=30)
    except Exception:
        abort(500, "No database connection could be established.")


#  Close Connection to Database
@app.teardown_request
def teardown_request(exception):
    try:
        g.sql_conn.close()
    except AttributeError:
        pass


"""Page Renders"""
"""Main Pages"""


#  Default Page
@app.route('/')
def default_page():
    return render_template('index.html',
                           title='Home Page',
                           message='Welcome to the Ritz Theater Sales Database Web API',
                           mimetype='text/html'
                           ), 200


#  Help Page
@app.route('/help')
def api_help():
    return render_template('api_help.html',
                           title='Help Page',
                           mimetype='text/html'
                           ), 200


#  Deleting Records Page
@app.route('/idiot')  # may need to change this
def delete_record():
    return render_template('deletion.html',
                           mimetype='text/html',
                           title='Deleting Records',
                           message="""YOU SHALL NOT PASS!"""
                           ), 200


"""Box Office Report Pages"""


#  Single Report Search Page
@app.route('/search_single')
def search_bo_single():
    return render_template('search_single.html',
                           title='Single Showing Box Office Report',
                           message='Box Office reporting data for a single showing. \n For internal use only!',
                           mimetype='text/html'
                           ), 200


#  Report Generator
@app.route('/search_range')
def search_bo_range():
    return render_template('search_range.html',
                           mimetype='text/html'
                           ), 200


#  Search by Distributor
@app.route('/search_dist')
def search_bo_dist():
    return render_template('search_dist.html',
                           mimetype='text/html'
                           ), 200


#  Search by Rating
@app.route('/search_rating')
def search_bo_rating():
    return render_template('search_rating.html',
                           mimetype='text/html'
                           ), 200


#  Search by Title
@app.route('/search_title')
def search_bo_title():
    return render_template('search_title.html',
                           mimetype='text/html'
                           ), 200


"""Search Pages"""


#  Search Single Records
@app.route('/search_records')
def search_records_page():
    return render_template('search_records.html',
                           mimetype='text/html',
                           title='Search Single Database Records',
                           message='Choose a table to search and enter a key value.'
                           ), 200


#  Search Views
@app.route('/search_views_page')
def search_views_page():
    return render_template('search_views.html',
                           mimetype='text/html',
                           title='Search Views',
                           message='Select a view to search. Enter dates as YYYY/MM/DD.'
                           ), 200


#  Search All Records
@app.route('/search_all_records')
def search_all_records_page():
    return render_template('search_records_all.html',
                           mimetype='text/html',
                           title='Search All Records',
                           message='Choose a table to search.'
                           ), 200


"""Adding Records Pages"""


#  Adding Feature Records
@app.route('/add_feature')
def add_feature_page():
    return render_template('add_feature.html',
                           mimetype='text/html',
                           title='Add Feature Records',
                           message='All fields marked with * are required. Format dates as YYYY/MM/DD.'
                           ), 200


#  Adding Employee Records
@app.route('/add_employee')
def add_employee_page():
    return render_template('add_employee.html',
                           mimetype='text/html',
                           title='Add Employee',
                           message='All fields marked with * are required.'
                           ), 200


#  Adding Sales Records
@app.route('/add_sale')
def add_sales_page():
    return render_template('add_sale.html',
                           mimetype='text/html',
                           title='Add Sales Records',
                           message='All fields marked with * are required. Format dates as YYYY/MM/DD.'
                           ), 200


#  Adding Ticket Records
@app.route('/add_ticket')
def add_ticket_page():
    return render_template('add_ticket.html',
                           mimetype='text/html',
                           title='Add Ticket Sales Records',
                           message='All fields marked with * are required.\nFormat dates as YYYY/MM/DD.\n'
                                   'Input time like 5:00 pm'
                           ), 200


#  Adding Concession Records
@app.route('/add_concession')
def add_concession_page():
    return render_template('add_concession.html',
                           mimetype='text/html',
                           title='Add Concessions Sales Records',
                           message='All fields marked with * are required.\nFormat dates as YYYY/MM/DD.\n'
                                   'Input time like 5:00 pm'
                           ), 200


"""Update Records"""


#  Update Employee
@app.route('/update_employee')
def update_employee_page():
    return render_template('update_employee.html',
                           mimetype='text/html'
                           ), 200


#  Update Feature
@app.route('/update_feature')
def update_feature_page():
    return render_template('update_feature.html',
                           mimetype='text/html'
                           ), 200


"""Query Functions"""


#  Execute Query and Store
def execute_query(query):
    curs = g.sql_conn.cursor()
    curs.execute(query)

    keys = [column[0] for column in curs.description]
    data = {}
    i = 0

    for row in curs.fetchall():
        data[i] = row
        i += 1
    return keys, data  # implicit cast to tuple?


#  Execute SQL queries and commits the changes to the database
def execute_commit_ops(query):
    curs = g.sql_conn.cursor()
    curs.execute(query)
    curs.commit()

    return 'success', 200
#  Creates a cursor variable, executes the query variable/parameter, commits the changes to the database, and returns a
#  200 code if successful.


#  1000 Results Function
def execute_1000(query):
    curs = g.sql_conn.cursor()
    curs.execute(query)
    keys = [column[0] for column in curs.description]
    data = {}
    i = 0
    for row in curs.fetchall():
        data[i] = row
        i += 1
        if i > 1000:
            break
    return keys, data


"""API Section"""


""""Search Table Records"""


#  Search Single Records Function All Tables
@app.route('/search_records/single', methods=['POST', 'GET'])
def search_records_single():
    if request.method == 'POST':

        table_name = request.form['table']
        if table_name == 'FEATURE':
            table_key = 'FeatureID'
        elif table_name == 'EMPLOYEE':
            table_key = 'EmployeeID'
        elif table_name == 'CONCESSION_SALES':
            table_key = 'ConSaleID'
        elif table_name == 'TICKET_SALES':
            table_key = 'GrossID'
        else:
            table_key = 'SalesID'
        query = f"""SELECT * FROM {request.form['table']} WHERE {table_key}={request.form['key_value']}"""
        query_result = execute_query(query)
        return Response(render_template('search_records_temp.html',
                                        result=query_result[1],
                                        keys=query_result[0],
                                        mimetype='text/html',
                                        title=f'Single {table_name} Record',
                                        message=f'Record from {table_name} by ID'
                                        )), 200
    else:
        return render_template('search_records.html',
                               mimetype='text/html',
                               ), 200


#  Search Sales Views
@app.route('/search_views', methods=['POST', 'GET'])
def search_view():
    if request.method == 'POST':
        view_name = request.form['view']
        query = f"""SELECT * FROM {view_name}"""
        show_time_string = request.form['show_time']
        first_date = request.form['firstDate']
        last_date = request.form['lastDate']
        if first_date:
            first_date_formatted = format_date_string(first_date)
        if last_date:
            last_date_formatted = format_date_string(last_date)
        if first_date or show_time_string or last_date:
            query += f""" WHERE"""
            if first_date and last_date:
                query += f""" Date between '{first_date_formatted}' and '{last_date_formatted}'"""
            elif first_date:
                query += f""" Date='{first_date_formatted}'"""
            if first_date and show_time_string:
                query += ' and'
            if show_time_string:
                query += f""" TimeOfShow LIKE '{show_time_string}%'"""
        query_result = execute_query(query)
        return Response(render_template('search_views_temp.html',
                                        result=query_result[1],
                                        keys=query_result[0],
                                        mimetype='text/html',
                                        title=f"""{view_name} Search""",
                                        message=f"""Results from Database View"""))
    else:
        return render_template('search_views.html',
                               mimetype='text/html',
                               ), 200


#  1000 Results Search
@app.route('/search_records/1000', methods=['POST', 'GET'])
def search_1000_records():
    if request.method == 'POST':

        table_name = request.form['table']
        if table_name == 'FEATURE':
            table_key = 'FeatureID'
        elif table_name == 'EMPLOYEE':
            table_key = 'EmployeeID'
        elif table_name == 'CONCESSION_SALES':
            table_key = 'ConSaleID'
        elif table_name == 'TICKET_SALES':
            table_key = 'GrossID'
        else:
            table_key = 'SalesID'
        query = f"""SELECT * FROM {request.form['table']} WHERE {table_key}={request.form['key_value']}"""
        query_result = execute_1000(query)
        return Response(render_template('search_records_1K_temp.html',
                                        result=query_result[1],
                                        keys=query_result[0],
                                        mimetype='text/html',
                                        title=f'1000 Records from {table_name}',
                                        message=f'Record from {table_name} by ID'
                                        )), 200
    else:
        return render_template('search_records_1k.html',
                               mimetype='text/html',
                               ), 200


#  Search All Records Function All Tables
@app.route('/search_records/all', methods=['POST', 'GET'])
def search_records_all():
    if request.method == 'POST':

        table_name = request.form['table']
        query = f"""SELECT * FROM {request.form['table']}"""
        query_result = execute_query(query)
        return Response(render_template('search_records_all_temp.html',
                                        result=query_result[1],
                                        keys=query_result[0],
                                        mimetype='text/html',
                                        title=f'All Records Query',
                                        message=f'All Records from {table_name}'
                                        )), 200
    else:
        return render_template('search_records_all.html',
                               mimetype='text/html',
                               ), 200


#  Get Manager ID's Only
@app.route('/search/managers', methods=['GET'])
def get_managers():
    query = """select * from Employee where EmployeeType='Manager' or EmployeeType='Owner'"""
    query_result = execute_query(query)
    return Response(render_template('report_temp.html',
                                    result=query_result[1],
                                    keys=query_result[0],
                                    mimetype='text/html',
                                    title='Manager List',
                                    message='List of Managers Past and Present with contact information'
                                    )), 200


"""Add and Update Records"""


#  Ticket Sales
#  (Add) Ticket Sale
@app.route('/api/rs/sales/tickets/add', methods=['POST'])
def insert_new_ticket_sale():
    if request.method == 'POST':
        feature_id = int(request.form['FeatureID'])
        feature_date = request.form['Date']
        feature_date_formatted = format_date_string(feature_date)
        opening_number = int(request.form['OpeningNumber'])
        closing_number = int(request.form['ClosingNumber'])
        ticket_price = int(request.form['TicketPrice'])
        query = f"""insert into Ticket_Sales VALUES ({feature_id},'{feature_date_formatted}',"""\
                f"""'{request.form['DayOfWeek']}','{request.form['TimeOfShow']}',{opening_number},{closing_number},"""\
                f"""{ticket_price})"""
        execute_commit_ops(query)

        return render_template('add_ticket.html'), 200
    else:
        return render_template('add_ticket.html'), 200


#  Concessions Sales
# (Add) Concessions Entry
@app.route('/api/rs/sales/concession/add', methods=['GET', 'POST'])
def insert_new_concession_sale():
    if request.method == 'POST':
        sale_date = request.form['date']
        sale_date_formatted = format_date_string(sale_date)
        total_sales = Decimal(request.form['total_sales'])
        screen = int(request.form['screen'])
        query = f"""insert into Concession_Sales VALUES ('{sale_date_formatted}','{total_sales}',"""\
                f"""'{request.form['time']}',{screen})"""
        execute_commit_ops(query)

        return render_template('add_concession.html'), 200
    else:
        return render_template('add_concession.html'), 200


#  Employee Section
#  (Add) Employee
@app.route('/api/rs/sales/employee/add', methods=['GET', 'POST'])
def insert_employee():
    if request.method == 'POST':

        query = f"""insert into EMPLOYEE VALUES ('{request.form['f_name']}','{request.form['l_name']}',""" \
                f"""'{request.form['phone']}','{request.form['cell']}','{request.form['email']}',""" \
                f"""'{request.form['employee']}','{request.form['active']}')"""

        execute_commit_ops(query)

        return render_template('add_employee.html'), 200
    else:
        return render_template('add_employee.html'), 200


#  Update Employee
@app.route('/api/rs/sales/employee/update', methods=['GET', 'POST'])
def update_employee():
    if request.method == 'POST':

        query = f"""UPDATE EMPLOYEE SET {request.form['column']} = '{request.form['change']}'""" \
                f""" WHERE EmployeeID = '{request.form['emp_id']}'"""

        execute_commit_ops(query)

        return render_template('update_employee.html'), 200
    else:
        return render_template('update_employee.html'), 200


#  Feature Section
#  (Add) Feature
@app.route('/api/rs/sales/feature/add', methods=['GET', 'POST'])
def insert_new_feature():
    if request.method == 'POST':
        show_title = request.form['ShowTitle']
        show_title_formatted = show_title.replace('+', ' ')
        open_date = request.form['OpenDate']
        open_date_formatted = format_date_string(open_date)
        close_date = request.form['CloseDate']
        if close_date != '':
            close_date_formatted = format_date_string(close_date)
        distributor = request.form['Distributor']
        distributor_formatted = distributor.replace('+', ' ')
        query = f"""insert into Feature VALUES ('{show_title_formatted}','{request.form['YearReleased']}',""" \
                f"""'{request.form['Rating']}','{open_date_formatted}','{close_date_formatted}',""" \
                f"""'{distributor_formatted}','{request.form['Screen']}')"""
        if execute_commit_ops(query) is 'success':
            return render_template('add_feature.html'), 200
        else:
            return render_template('error.html'), 400
    else:
        return render_template('add_feature.html'), 200


#  Update Feature
@app.route('/api/rs/sales/feature/update', methods=['GET', 'POST'])
def update_feature():
    if request.method == 'POST':
        close_date = request.form['CloseDate']
        close_date_formatted = format_date_string(close_date)
        query = f"""UPDATE FEATURE SET CloseDate = '{close_date_formatted}'""" \
                f""" WHERE FeatureID = '{request.form['feature_id']}'"""

        execute_commit_ops(query)

        return render_template('update_feature.html'), 200
    else:
        return render_template('update_feature.html'), 200


#  Sales Section
#  Add Sales Entry
@app.route('/api/rs/sales/sales/add', methods=['GET', 'POST'])
def insert_new_sale():
    if request.method == 'POST':
        feature_id = int(request.form['feature_id'])
        sale_date = request.form['date']
        sale_date_formatted = format_date_string(sale_date)
        gross_id = int(request.form['gross_id'])
        manager_id = int(request.form['manager'])
        concession_id = int(request.form['con_id'])
        query = f"""insert into Sales Values ('{sale_date_formatted}',{feature_id},{gross_id},""" \
                f"""{manager_id},{concession_id})"""
        execute_commit_ops(query)
        return render_template('add_sale.html'), 200
    else:
        return render_template('add_sale.html'), 400


"""Delete Records !!!DO NOT IMPLEMENT!!! !!!DO NOT USE!!!
Deleting records from the database violates the referential integrity of the database and the business rules 
of the data system. These functions have been included in the code for future convienience only.
"""
"""
#  DELETE Ticket Sale DO NOT USE!!!!!!! violates database referential integrity
@app.route('/api/rs/sales/tickets/delete/<int:gross_id>', methods=['DELETE'])
def delete_ticket_sale(gross_id):
    query = f"DELETE FROM Ticket_Sales WHERE GrossID = {gross_id}"
    return execute_commit_ops(query)
"""

"""
#  DELETE Concessions DO NOT USE!!!!!!! violates database referential integrity
@app.route('/api/rs/sales/concession/delete/<int:con_id>', methods=['DELETE'])
def delete_concession_sale(con_id):
    query = f"DELETE FROM Concession_Sales WHERE ConSaleID = {con_id}"
    return execute_commit_ops(query)
"""


"""
#  DELETE Employee DO NOT USE!!!!!!! violates database referential integrity
@app.route('/api/rs/sales/employee/delete/<int:emp_id>', methods=['DELETE'])
def delete_employee(emp_id):
    query = f"DELETE FROM Employee WHERE EmployeeID = {emp_id}"
    return execute_commit_ops(query)
"""


"""
#  DELETE Feature DO NOT USE!!!!!!! violates database referential integrity
@app.route('/api/rs/sales/feature/delete/<int:feature_id>', methods=['DELETE'])
def delete_feature(feature_id):
    query = f"DELETE FROM Feature WHERE FeatureID = {feature_id}"
    return execute_commit_ops(query)
"""

#  A Delete Function has not been included for the Sales table


"""API Reports Section"""


#  Box Office Report Section
#  All Reports
@app.route('/api/rs/sales/bo_report', methods=['GET'])
def get_report():
    query = """select * from BoxOfficeReport"""
    query_result = execute_query(query)
    #  round Decimal results of currency columns to 2 places
    for i in range(0, len(query_result[1])):
        query_result[1][i][6] = round(query_result[1][i][6], 2)
        query_result[1][i][7] = round(query_result[1][i][7], 2)
        query_result[1][i][8] = round(query_result[1][i][8], 2)
    return Response(render_template('report_temp.html',
                                    result=query_result[1],
                                    keys=query_result[0],
                                    mimetype='text/html',
                                    title='Box Office Reports',
                                    message='All Box Office Reports, for internal use'
                                    )), 200


#  Box Office Report by Date Single
"""Enter Dates with the format MMDDYYYY including a 0 for single digit value months and dates"""


@app.route('/api/rs/sales/bo_report_single/<string:show_title>/<string:show_time>/<string:show_date>', methods=['GET'])
def get_single_bo_report(show_date, show_time, show_title):
    date_string = show_date[0:2] + '/' + show_date[2:4] + '/' + show_date[4:8]
    query = f"""select * from BoxOfficeReport where Date = '{date_string}' and ShowTime like '{show_time}%' and """\
            f"""ShowTitle like '%{show_title}%'"""
    query_result = execute_query(query)
    sum_total = 0
    sum_tax = 0
    sum_net = 0
    #  round Decimal results of currency columns to 2 places
    for i in range(0, len(query_result[1])):
        query_result[1][i][6] = round(query_result[1][i][6], 2)
        query_result[1][i][7] = round(query_result[1][i][7], 2)
        query_result[1][i][8] = round(query_result[1][i][8], 2)
    #  Total statistics for currency columns
        sum_total += query_result[1][i][6]
        sum_tax += query_result[1][i][7]
        sum_net += query_result[1][i][8]
    other_vars = {'Total Gross': sum_total, 'Total Tax': sum_tax, 'Total Net Gross': sum_net}
    return Response(render_template('report_temp.html',
                                    result=query_result[1],
                                    keys=query_result[0],
                                    other_vars_keys=list(other_vars.keys()),
                                    other_vars_values=list(other_vars.values()),
                                    mimetype='text/html',
                                    title='Box Office Reports',
                                    message='Single Box Office Report, for internal use'
                                    )), 200


#  Box Office Report for Date Range
"""Enter Dates with the format MMDDYYYY including a 0 for single digit value months and dates"""


@app.route('/api/rs/sales/bo_report_range/<string:first_date>/<string:last_date>/<string:show_title>', methods=['GET',
                                                                                                                'POST'])
def get_bo_report_range(first_date, last_date, show_title):
    first_date_string = first_date[0:2] + '/' + first_date[2:4] + '/' + first_date[4:8]
    last_date_string = last_date[0:2] + '/' + last_date[2:4] + '/' + last_date[4:8]
    query = f"""select * from BoxOfficeReport where Date between '{first_date_string}' and '{last_date_string}'"""\
            f"""and ShowTitle like '%{show_title}%'"""
    query_result = execute_query(query)
    sum_net = 0
    percentage = int(request.args.get('percentage'))
    percentage_formatted = Decimal(percentage / 100)
#  round Decimal results of currency columns to 2 places
    for i in range(0, len(query_result[1])):
        query_result[1][i][6] = round(query_result[1][i][6], 2)
        query_result[1][i][7] = round(query_result[1][i][7], 2)
        query_result[1][i][8] = round(query_result[1][i][8], 2)
        sum_net += query_result[1][i][8]
        net_paid = Decimal(sum_net * percentage_formatted)
        net_paid_rounded = round(net_paid, 2)
    other_vars = {'Ticket Price': f'${PRICE:.2f}', 'Sales Tax Rate': f'{(SALES_TAX*100):.2f}%', 'Total Net Gross':
                  f'${sum_net}', 'Percentage': f'{percentage}%', 'Total Paid': f'${net_paid_rounded}'}
    dist_var = {'Distributor': query_result[1][0][-1]}
    feature_var = {'Feature Title': query_result[1][0][1]}
    first_date_var = {'First Date': query_result[1][0][0]}
    last_date_var = {'Last Date': query_result[1][6][0]}
    return Response(render_template('bo_report.html',
                                    result=query_result[1],
                                    keys=query_result[0],
                                    other_vars_keys=list(other_vars.keys()),
                                    other_vars_values=list(other_vars.values()),
                                    dist_var_key=list(dist_var.keys()),
                                    dist_var_value=list(dist_var.values()),
                                    feature_var_key=list(feature_var.keys()),
                                    feature_var_value=list(feature_var.values()),
                                    first_date_var_key=list(first_date_var.keys()),
                                    first_date_var_value=list(first_date_var.values()),
                                    last_date_var_key=list(last_date_var.keys()),
                                    last_date_var_value=list(last_date_var.values()),
                                    mimetype='text/html',
                                    title='Box Office Reports',
                                    message2='Box Office Report for:',
                                    theater_name=BUSINESS_NAME,
                                    street_address=BUSINESS_ADDRESS,
                                    city_state=BUSINESS_CITY_STATE,
                                    owner_name=f'Prepared by {BUSINESS_OWNER}',
                                    owner_title=BUSINESS_OWNER_TITLE
                                    )), 200


#  Box Office Report by Feature
@app.route('/api/rs/sales/bo_report_feature/<string:show_title>', methods=['GET'])
def get_single_bo_report_feature(show_title):
    query = f"""select * from BoxOfficeReport where ShowTitle like '%{show_title}%'"""
    query_result = execute_query(query)
    sum_total = 0
    sum_tax = 0
    sum_net = 0
    #  round Decimal results of currency columns to 2 places
    for i in range(0, len(query_result[1])):
        query_result[1][i][6] = round(query_result[1][i][6], 2)
        query_result[1][i][7] = round(query_result[1][i][7], 2)
        query_result[1][i][8] = round(query_result[1][i][8], 2)
        sum_total += query_result[1][i][6]
        sum_tax += query_result[1][i][7]
        sum_net += query_result[1][i][8]
    other_vars = {'Total Gross': sum_total, 'Total Tax': sum_tax, 'Total Net Gross': sum_net}
    return Response(render_template('report_temp.html',
                                    result=query_result[1],
                                    keys=query_result[0],
                                    other_vars_keys=list(other_vars.keys()),
                                    other_vars_values=list(other_vars.values()),
                                    mimetype='text/html',
                                    title='Box Office Reports',
                                    message='Box Office Reports by Feature, for internal use'
                                    )), 200


#  Box Office Report By Rating
@app.route('/api/rs/sales/bo_report_rating/<string:rating>', methods=['GET'])
def get_bo_report_rating(rating):
    query = f"""select * from BoxOfficeReport where Rating like '%{rating}%'"""
    query_result = execute_query(query)
    sum_total = 0
    sum_tax = 0
    sum_net = 0
    #  round Decimal results of currency columns to 2 places
    for i in range(0, len(query_result[1])):
        query_result[1][i][6] = round(query_result[1][i][6], 2)
        query_result[1][i][7] = round(query_result[1][i][7], 2)
        query_result[1][i][8] = round(query_result[1][i][8], 2)
        sum_total += query_result[1][i][6]
        sum_tax += query_result[1][i][7]
        sum_net += query_result[1][i][8]
    other_vars = {'Total Gross': sum_total, 'Total Tax': sum_tax, 'Total Net Gross': sum_net}
    return Response(render_template('report_temp.html',
                                    result=query_result[1],
                                    keys=query_result[0],
                                    other_vars_keys=list(other_vars.keys()),
                                    other_vars_values=list(other_vars.values()),
                                    mimetype='text/html',
                                    title='Box Office Reports',
                                    message='Box Office Reports by Rating, for internal use'
                                    )), 200


#  Box Office Report by Distributor
@app.route('/api/rs/sales/bo_report_dist/<string:distributor>', methods=['GET'])
def get_bo_report_distributor(distributor):
    query = f"""select * from BoxOfficeReport where Distributor like '%{distributor}%'"""
    query_result = execute_query(query)
    sum_total = 0
    sum_tax = 0
    sum_net = 0
    #  round Decimal results of currency columns to 2 places
    for i in range(0, len(query_result[1])):
        query_result[1][i][6] = round(query_result[1][i][6], 2)
        query_result[1][i][7] = round(query_result[1][i][7], 2)
        query_result[1][i][8] = round(query_result[1][i][8], 2)
        sum_total += query_result[1][i][6]
        sum_tax += query_result[1][i][7]
        sum_net += query_result[1][i][8]
    other_vars = {'Total Gross': sum_total, 'Total Tax': sum_tax, 'Total Net Gross': sum_net}
    return Response(render_template('report_temp.html',
                                    result=query_result[1],
                                    keys=query_result[0],
                                    other_vars_keys=list(other_vars.keys()),
                                    other_vars_values=list(other_vars.values()),
                                    mimetype='text/html',
                                    title='Box Office Reports',
                                    message='Box Office Reports by Distributor, for internal use'
                                    )), 200


#  Other Functions
#  Employee Contact Sheet
@app.route('/api/rs/sales/employee_contact', methods=['GET'])
def generate_contact_sheet():
    query = f"""SELECT * FROM Employee_Info WHERE Active='Yes'"""
    query_result = execute_query(query)
    return Response(render_template('report_temp.html',
                                    result=query_result[1],
                                    keys=query_result[0],
                                    mimetype='text/html',
                                    title='Employee Information',
                                    message='Employee Contact Sheet'
                                    )), 200


if __name__ == '__main__':
    #  Global Variables for easy update
    #  Constant variables that will not be changed often, but could break things if a mistake is made
    #  Global variables are bad, and these really should be hidden in a class
    SALES_TAX = 0.0685
    PRICE = 2.00
    BUSINESS_NAME = 'The Ritz Theater'
    BUSINESS_ADDRESS = '111 N. Main St.'
    BUSINESS_CITY_STATE = 'Tooele, UT 84074'
    BUSINESS_OWNER = 'Alan D. Bradshaw'
    BUSINESS_OWNER_TITLE = 'CEO, Ritz Management Corp.'
    app.run()
